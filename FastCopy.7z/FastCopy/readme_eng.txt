﻿======================================================================
                   FastCopy  ver3.41                   2018/01/27
                                                 SHIROUZU Hiroaki
======================================================================

	FastCopy is the Fastest Copy/Delete Software on Windows.

	It can copy/delete unicode and over MAX_PATH(260byte) pathname files.

	It always run by multi-threading.

	It don't use MFC, it is compact and don't requre mfcxx.dll.

	FastCopy is GPLv3 license, you can modify and use under GPLv3

License:
	-------------------------------------------------------------------------
	 FastCopy ver3.x
	 Copyright(C) 2004-2018 SHIROUZU Hiroaki All rights reserved.

	 This program is free software. You can redistribute it and/or modify
	 it under the GNU General Public License version 3.

	 If you want to distribute your modified version, but you don't want to
	 distribute the modified source code, please contact shirouzu@ipmsg.org

	 more details: license-gpl3.txt
	-------------------------------------------------------------------------

	xxHash library Copyright (C) 2012-2014 Mr.Yann Collet, All rights reserved.
	  more details: external/xxhash/LICENSE

Usage：
	Please see fastcopy.chm

Build:
	VS2015 or later

